#include <errno.h>

#include <linux/sched.h>
#include <linux/kernel.h>
#include <linux/tty.h>

extern int tty_read(unsigned minor,char * buf,int count);
extern int tty_write(unsigned minor,char * buf,int count);

static int rw_ttyx(int rw,unsigned minor,char * buf,int count);
static int rw_tty(int rw,unsigned minor,char * buf,int count);

typedef int (*crw_ptr)(int rw,unsigned minor,char * buf,int count);

#define NRDEVS ((sizeof (crw_table))/(sizeof (crw_ptr)))

static crw_ptr crw_table[]={
	NULL,		/* nodev */
	NULL,		/* /dev/mem */
	NULL,		/* /dev/fd */
	NULL,		/* /dev/hd */
	rw_ttyx,	/* /dev/ttyx */
	rw_tty,		/* /dev/tty */
	NULL,		/* /dev/lp */
	NULL};		/* unnamed pipes */

static int rw_ttyx(int rw,unsigned minor,char * buf,int count)
{
	if (minor >= NR_TTYS)
		return -ENXIO;
	return ((rw==READ)?tty_read(minor,buf,count):
		tty_write(minor,buf,count));
}

static int rw_tty(int rw,unsigned minor,char * buf,int count)
{
	if (current->tty<0)
		return rw_ttyx(rw,0,buf,count);
	return rw_ttyx(rw,current->tty,buf,count);
}

int rw_char(int rw,int dev, char * buf, int count)
{
	crw_ptr call_addr;

	if (MAJOR(dev)>=NRDEVS)
		return -ENXIO;
	if (!(call_addr=crw_table[MAJOR(dev)]))
		return -ENXIO;
	return call_addr(rw,MINOR(dev),buf,count);
}
